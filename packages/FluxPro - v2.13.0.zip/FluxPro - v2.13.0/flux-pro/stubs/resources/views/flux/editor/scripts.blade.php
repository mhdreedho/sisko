@blaze

{!! app('flux')->editorScripts() !!}
